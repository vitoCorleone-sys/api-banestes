<?php
//include_once("/var/lib/asterisk/agi-bin/phpagi-2.20/phpagi.php");
require '/var/lib/asterisk/agi-bin/api-banestes/vendor/autoload.php';
require '/var/lib/asterisk/agi-bin/api-banestes/Config/config.php';
//$agi = new AGI();

class Api{

/*  public function getApi(){
        $client = new SoapClient(BASE_URL_SDM); 
        $arguments = [
            'login' => [
                'username' => API_KEY_SDM,
                'password' => API_PASSWORD_SDM
            ]
                
        ];
        $result = $client->__soapCall('login', $arguments);
        return $result;
    } */


    public function getWS(){
      $xmlstr = 
      "<soapenv:Envelope xmlns:soapenv='http://schemas.xmlsoap.org/soap/envelope/' xmlns:ser='http://www.ca.com/UnicenterServicePlus/ServiceDesk'>
      <soapenv:Header/>
      <soapenv:Body>
         <ser:login>
            <username>U_SOL</username>
            <password>lhsol001</password>
         </ser:login>
        </soapenv:Body>
      </soapenv:Envelope>";
      $xml = new SimpleXMLElement($xmlstr);
//      $client = new SoapClient('http://h0wvap01s84/axis/services/USD_R11_WebService?wsdl');
//      $client = new SoapClient('http://helpdeskonline.banestes.com.br/axis/services/USD_R11_WebService?wsdl');
      $client = new SoapClient('http://helpdeskonline.h.banestes.com.br/axis/services/USD_R11_WebService?wsdl');
      $function = 'login';
      $arguments= array($xml);
      $result = $client->__soapCall($function, $arguments);
      echo 'Response: ';
      $json = json_decode($result, true);
  }

   
}
