<?php

require './vendor/autoload.php';

class Util {

    

    public static function formatCpf($doc){
        
        $doc = preg_replace("/[^0-9]/", "", $doc);
        
        $docFormatado = substr($doc, 0,3).'.'.substr($doc, 3,3).'.'.substr($doc, 6,3).'-'.substr($doc, 6,3);
        
        return $docFormatado;

    }


}

