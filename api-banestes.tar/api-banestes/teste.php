#!/usr/bin/php -q

<?php

$client = new SoapClient('http://helpdeskonline.h.banestes.com.br/axis/services/USD_R11_WebService?wsdl');
 
$function = 'login';
 
$arguments= array('login' => array(
                        'username'   => 'U_SOL',
                        'password'   => 'lhsol001'
                ));
//$options = array('location' => 'http://www.webservicex.net/ConvertTemperature.asmx');
 
//$result = $client->__soapCall($function, $arguments, $options);
$result = $client->__soapCall($function, $arguments);
 
echo 'Response: ';
print_r($result);






