<?php

require './vendor/autoload.php';
require('./db/connection.php');

class Model {
    
/*
    public static function getSessionToken(){
        $pdo = Database::conexao();
        $sql = "SELECT access_token, expires_in, refresh_expires_in, refresh_token FROM token;";
        $stmt = $pdo->prepare($sql); 
        $stmt->execute(); 
        $result = $stmt->fetch(PDO::FETCH_OBJ); 
        return $result;
    }


    public static function insertToken($access_token, $expiresin, $refreshexpires, $refresh_token){
        $pdo = Database::conexao();
        $sql = "INSERT INTO token(access_token, expires_in, refresh_expires_in, refresh_token) VALUES (:access_token, :expires_in, :refresh_expires_in, :refresh_token);";
        $stmt = $pdo->prepare($sql); 
        $stmt->bindParam(':access_token', $access_token, PDO::PARAM_STR);
        $stmt->bindParam(':expires_in', $expiresin, PDO::PARAM_STR);
        $stmt->bindParam(':refresh_expires_in', $refreshexpires, PDO::PARAM_STR);
        $stmt->bindParam(':refresh_token', $refresh_token, PDO::PARAM_STR);
        $stmt->execute(); 

    }
    
    public static function searchClient($cpf){
        $pdo = Database::conexao();
        $sql = "SELECT cpf, name, email, email_verified, birth_date, phone_number_country, phone_number_area, phone_number_number, created_at,
        device_os, mobile_phone_verified FROM client WHERE cpf = :cpf;";
        $stmt = $pdo->prepare($sql); 
        $stmt->bindParam(':cpf', $cpf, PDO::PARAM_STR);
        $stmt->execute(); 
        $result = $stmt->fetch(PDO::FETCH_OBJ);
        return $result;
    }

    public static function searchTicketClient($cpf){
        $pdo = Database::conexao();
        $sql = "SELECT idTicket, cpfTicket, source, subjetc, comment, tagsArray, custom_fields_id, custom_fields_value, createTicket 
        FROM ticketclient WHERE CONCAT(idTicket,cpfTicket) like CONCAT('%',:cpf,'%');";
        $stmt = $pdo->prepare($sql); 
        $stmt->bindParam(':cpf', $cpf, PDO::PARAM_STR);
        $stmt->execute(); 
    }

    public static function truncateToken(){
        $pdo = Database::conexao();
        $sql = "TRUNCATE TABLE token;";
        $stmt = $pdo->prepare($sql); 
        $stmt->execute(); 

    }


    public static function recordClientInfo($dates){
        $pdo = Database::conexao();
        $sql = "INSERT INTO client(name, email, email_verified, cpf, birth_date, phone_number_country, phone_number_area, phone_number_number, created_at,
        device_os, mobile_phone_verified) VALUES (:name, :email, :email_verified, :cpf, :birth_date, :phone_number_country, :phone_number_area, :phone_number_number, 
        :created_at, :device_os, :mobile_phone_verified);";
        $stmt = $pdo->prepare($sql); 
        $stmt->bindParam(':name', $dates['name'], PDO::PARAM_STR);
        $stmt->bindParam(':email', $dates['email'], PDO::PARAM_STR);
        $stmt->bindParam(':email_verified', $dates['email_verified'], PDO::PARAM_STR);
        $stmt->bindParam(':cpf', $dates['cpf'], PDO::PARAM_STR);
        $stmt->bindParam(':birth_date', $dates['birth_date'], PDO::PARAM_STR);
        $stmt->bindParam(':phone_number_country', $dates['phone_number']['country'], PDO::PARAM_STR);
        $stmt->bindParam(':phone_number_area', $dates['phone_number']['area'], PDO::PARAM_STR);
        $stmt->bindParam(':phone_number_number', $dates['phone_number']['number'], PDO::PARAM_STR);
        $stmt->bindParam(':created_at', $dates['created_at'], PDO::PARAM_STR);
        $stmt->bindParam(':device_os', $dates['device_os'], PDO::PARAM_STR);
        $stmt->bindParam(':mobile_phone_verified', $dates['mobile_phone_verified'], PDO::PARAM_STR);
        $stmt->execute(); 
        return json_encode(['code'=>200, 'message'=>'Successfully registered customer']);
    }


    public static function recordTicketVoice($dates, $cpf){
        $pdo = Database::conexao();
        $sql = "INSERT INTO ticketVoice(id_ticket, cpf_ticket, created_at) VALUES (:id_ticket, :cpf_ticket, ()now);";
        $stmt = $pdo->prepare($sql); 
        $stmt->bindParam(':id_ticket', $dates['id'], PDO::PARAM_STR);
        $stmt->bindParam(':cpf_ticket', $cpf, PDO::PARAM_STR);
        $stmt->execute(); 
        return json_encode(['code'=>200, 'message'=>'Successfully registered ticket']);
    }

*/
    
}

