<?php
define("DRIVER_CONN", "mysql");
define("HOSTNAME", "localhost");
define("DATABASE", "picpay");
define("USERNAME", "root");
define("PASSWORD", "");
define("PASSWORD_PROD", "252525");
define("NAME_APP", "PicPayIntegra");
define("EMAIL_APP", "rafael@eycon.com.br");

define("BASE_URL", "https://api.picpay.com");
define("CLIENT_ID", "d79dbe12-7cf7-4c09-a126-882c749a3850");
define("CLIENT_SECRET", "399db3fe-2ed9-4fce-9698-f10ead0188cb");
define("API_KEY", "G9BvCyLl9M0ODh48nKvSmkIqHfXPB60w");

define("BASE_URL_HOM", "https://api.ms.qa.limbo.work/");
define("CLIENT_ID_HOM", "94866bd6-1438-4097-a767-6cee7384ae65");
define("CLIENT_SECRET_HOM", "a7002d39-899a-4885-95b5-6b458affe694");
define("API_KEY_HOM", "lTfcHr1nSsLxQU9Hd9TlmtFLuT0ZQ6zv");



define("API_KEY_SDM", "U_SOL");
define("API_PASSWORD_SDM", "lhsol001");
define("BASE_URL_SDM", "http://h0wvap01s84/axis/services/USD_R11_WebService?wsdl");



