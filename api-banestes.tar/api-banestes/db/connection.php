<?php
require('./Config/config.php');

class Database
{
  
  protected static $db;

   private function __construct()
  {
  
    try
      {
          self::$db = new PDO(DRIVER_CONN.":host=".HOSTNAME."; dbname=".DATABASE, USERNAME, PASSWORD);
          self::$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
          self::$db->exec('SET NAMES utf8');
      }
      catch (PDOException $e)
      {
            mail(EMAIL_APP, "PDOException em ".NAME_APP, $e->getMessage());
            die("Connection Error: " . $e->getMessage());
      }
  }

  public static function conexao()
  {
      if (!self::$db)
      {
          new Database();
      }
      return self::$db;
  }

}