#!/usr/bin/php -q
<?php
require '/var/lib/asterisk/agi-bin/api-banestes/vendor/autoload.php';
require('/var/lib/asterisk/agi-bin/api-banestes/api/api.php');

$api = new Api();
$result = $api->getWS();
